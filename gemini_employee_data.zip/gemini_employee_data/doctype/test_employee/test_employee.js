// Copyright (c) 2022, gemini and contributors
// For license information, please see license.txt

frappe.ui.form.on('Test Employee', {
	// refresh: function(frm) {

	// }
});
