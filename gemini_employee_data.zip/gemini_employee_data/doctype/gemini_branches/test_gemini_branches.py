# Copyright (c) 2022, gemini and Contributors
# See license.txt

# import frappe
import unittest

class TestGeminiBranches(unittest.TestCase):
	pass
