// Copyright (c) 2016, gemini and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Status based Employees"] = {
	"filters": [
		{
			"fieldname":"status",
			"label": __("Status"),
			"fieldtype": "Select",
			"options": "Active\nInactive\nSuspended\nLeft",
			//"default":frappe.defaults.get_user_default("Active") 
		}
	]
};

