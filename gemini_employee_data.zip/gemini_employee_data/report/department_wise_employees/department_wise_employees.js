// Copyright (c) 2016, gemini and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Department Wise Employees"] = {
	"filters": [
		{
			"fieldname":"department",
			"label": __("Department"),
			"fieldtype": "Link",
			"options": "All Departments",
			"default": frappe.defaults.get_user_default("All Departments")
		}
	]
};
