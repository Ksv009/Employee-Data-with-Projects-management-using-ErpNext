// Copyright (c) 2016, gemini and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Branch Wise Employees"] = {
	"filters": [
		{
			"fieldname":"branch",
			"label": __("Branch Name"),
			"fieldtype": "Link",
			"options": "Gemini Branches",
			"default": frappe.defaults.get_user_default("Gemini Branches")
		}

	]
};
