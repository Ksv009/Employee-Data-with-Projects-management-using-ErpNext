// Copyright (c) 2016, gemini and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Employee assign with projects"] = {
	"filters": [
		{
			"fieldname":"name",
			"label": __("EMP ID"),
			"fieldtype": "Link",
			"options": "GCS Employees",
			"default": frappe.defaults.get_user_default("GCS Employees")
		},
		{
			"fieldname":"project_name",
			"label": __("Project Name"),
			"fieldtype": "Link",
			"options": "GCS Projects",
			"default": frappe.defaults.get_user_default("GCS Projects")
		}

	]
};
