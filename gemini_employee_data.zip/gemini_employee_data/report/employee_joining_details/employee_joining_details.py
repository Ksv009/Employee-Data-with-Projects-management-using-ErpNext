# Copyright (c) 2013, gemini and contributors
# For license information, please see license.txt

# import frappe

def execute(filters=None):
	columns, data = [], []
	return columns, data
