// Copyright (c) 2016, gemini and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Employee Joining details"] = {
	"filters": [

	]
};
